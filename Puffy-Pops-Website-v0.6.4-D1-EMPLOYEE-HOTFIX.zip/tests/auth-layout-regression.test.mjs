import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("app API advertises the recovered role login methods", async () => {
  const source = await readFile(new URL("../app/api/app/health/route.ts", import.meta.url), "utf8");
  assert.match(source, /protocol:\s*5/);
  assert.match(source, /management-code/);
  assert.match(source, /cashier-credentials/);
  assert.match(source, /developer-code/);
});

test("cashier passwords no longer depend on session-secret rotation", async () => {
  const source = await readFile(new URL("../app/server/security.ts", import.meta.url), "utf8");
  assert.match(source, /return `v4\.\$\{await pbkdf2PasswordHash/);
  assert.match(source, /100_000/);
  assert.match(source, /storedHash\.startsWith\("v2\."\)/);
});

test("Cloudflare bindings are injected by the Worker instead of dynamically imported by routes", async () => {
  const files = [
    "../db/index.ts",
    "../app/api/media/route.ts",
    "../app/server/google-maps.ts",
    "../app/api/cms/catalog/route.ts",
    "../app/api/cms/upload/route.ts",
  ];
  for (const file of files) {
    const source = await readFile(new URL(file, import.meta.url), "utf8");
    assert.doesNotMatch(source, /import\(["']cloudflare:workers["']\)/, file);
  }
  const worker = await readFile(new URL("../worker/index.ts", import.meta.url), "utf8");
  assert.match(worker, /setRuntimeBindings\(\{/);
  assert.match(worker, /DB:\s*env\.DB/);
});

test("the owner can turn any worker into a credentialed cashier", async () => {
  const source = await readFile(new URL("../app/api/admin/staff/route.ts", import.meta.url), "utf8");
  assert.match(source, /body\.action === "set-cashier-credentials"/);
  assert.match(source, /role = 'cashier', active = 1, username = \?/);
  assert.doesNotMatch(source, /eq\(employees\.role, "cashier"\)\)\.limit\(1\)/);
  assert.doesNotMatch(source, /\.returning\(\)/);
});

test("manager assignment remains compatible with older employee tables", async () => {
  const source = await readFile(new URL("../app/api/admin/staff/route.ts", import.meta.url), "utf8");
  assert.match(source, /const storedRole = role === "manager" \? "team" : role/);
  assert.match(source, /INSERT INTO branch_profiles/);
  assert.doesNotMatch(source, /set\(\{ role: "manager"/);
});

test("home removes the overlapping pinned chapter and old logo hero", async () => {
  const page = await readFile(new URL("../app/page.tsx", import.meta.url), "utf8");
  const css = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  assert.doesNotMatch(page, /className="cinema-hero"/);
  assert.doesNotMatch(page, /className="cinema-chapter"/);
  assert.match(page, /className="puffy-home-hero"/);
  assert.match(page, /className="puffy-order-story"/);
  assert.match(css, /Reliable home composition: every section stays in normal document flow/);
  assert.match(css, /Story chapters use a stable editorial layout on every device/);
});
