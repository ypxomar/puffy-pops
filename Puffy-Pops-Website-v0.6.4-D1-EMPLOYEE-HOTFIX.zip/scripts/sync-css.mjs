import { copyFile, mkdir } from "node:fs/promises";
import { resolve } from "node:path";

const projectRoot = resolve(import.meta.dirname, "..");
const assetDirectory = resolve(projectRoot, "public", "assets");

await mkdir(assetDirectory, { recursive: true });
await copyFile(
  resolve(projectRoot, "app", "globals.css"),
  resolve(assetDirectory, "storefront.css"),
);
