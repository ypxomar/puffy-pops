"use client";

/* eslint-disable @next/next/no-img-element */

import { motion, useReducedMotion } from "motion/react";
import { useRef, useState } from "react";
import { branches } from "./catalog";
import ScrollProgress from "./components/ScrollProgress";
import SiteFooter from "./components/SiteFooter";
import SiteHeader from "./components/SiteHeader";

const premiumEase = [0.22, 1, 0.36, 1] as const;

const highlights = [
  { name: "Nutella", label: "The crowd favorite", image: "/api/media?slot=home-favorite-1", tone: "orange" },
  { name: "White Chocolate", label: "Soft, sweet, unmistakable", image: "/api/media?slot=home-favorite-2", tone: "green" },
  { name: "Caramel", label: "Golden and generous", image: "/api/media?slot=home-favorite-3", tone: "wine" },
] as const;

export default function HomePage() {
  const reduceMotion = useReducedMotion();
  const railRef = useRef<HTMLDivElement>(null);
  const [activeHighlight, setActiveHighlight] = useState(0);

  const moveRail = (direction: -1 | 1) => {
    railRef.current?.scrollBy({ left: direction * Math.min(window.innerWidth * 0.72, 760), behavior: reduceMotion ? "auto" : "smooth" });
  };

  const updateRailIndex = () => {
    const rail = railRef.current;
    const firstCard = rail?.querySelector<HTMLElement>(".cinema-highlight-card");
    if (!rail || !firstCard) return;
    const gap = Number.parseFloat(getComputedStyle(rail).columnGap || "0");
    setActiveHighlight(Math.max(0, Math.min(highlights.length - 1, Math.round(rail.scrollLeft / (firstCard.offsetWidth + gap)))));
  };

  return <main className="cinema-home">
    <ScrollProgress />
    <SiteHeader />

    <section className="puffy-home-hero">
      <motion.div className="puffy-home-hero-copy" initial={reduceMotion ? false : { opacity: 0, y: 34 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .85, ease: premiumEase }}>
        <p className="cinema-kicker">Puffy Pops Egypt</p>
        <h1>A little box<br />of <em>big joy.</em></h1>
        <p>Pick the bites you’re craving. We’ll load the right local menu, route the order to the nearest branch and use the exact delivery pin you choose.</p>
        <div className="cinema-actions">
          <motion.a href="/menu" className="cinema-button primary" whileHover={reduceMotion ? undefined : { y: -3 }} whileTap={reduceMotion ? undefined : { scale: .98 }}>Build your box <span>↗</span></motion.a>
          <a href="/locations" className="cinema-button secondary">See locations <span>→</span></a>
        </div>
        <div className="puffy-home-proof"><span><strong>{branches.length}</strong> branches</span><span><strong>2</strong> local menus</span><span><strong>1</strong> exact pin</span></div>
      </motion.div>
      <motion.figure className="puffy-home-hero-visual" initial={reduceMotion ? false : { opacity: 0, x: 48, rotate: 1.5 }} animate={{ opacity: 1, x: 0, rotate: 0 }} transition={{ duration: 1, delay: .08, ease: premiumEase }}>
        <img src="/api/media?slot=home-hero" alt="Puffy Pops dessert boxes ready to share" />
        <figcaption><span>THE BOX OF THE MOMENT</span><strong>Pick. Pin.<br />Pop.</strong></figcaption>
        <i aria-hidden="true">PP</i>
      </motion.figure>
    </section>

    <section className="cinema-belief" id="belief">
      <motion.p className="cinema-kicker" initial={reduceMotion ? false : { opacity: 0, x: -24 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: 0.7 }} transition={{ duration: 0.65, ease: premiumEase }}>The Puffy idea</motion.p>
      <motion.h2 initial={reduceMotion ? false : { opacity: 0, clipPath: "inset(0 0 100% 0)", y: 46 }} whileInView={{ opacity: 1, clipPath: "inset(0 0 0% 0)", y: 0 }} viewport={{ once: true, amount: 0.42 }} transition={{ duration: 1, ease: premiumEase }}>Opening the box should feel exciting <em>before the first bite.</em></motion.h2>
      <motion.p initial={reduceMotion ? false : { opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true, amount: 0.8 }} transition={{ duration: 0.75, delay: 0.18 }}>Soft dough, generous fillings, playful flavors, and a menu that follows the customer—not the other way around.</motion.p>
    </section>

    <section className="puffy-order-story" aria-label="How a Puffy Pops order comes together">
      <div className="puffy-order-story-heading"><p className="cinema-kicker">One box. Three easy moves.</p><h2>No scroll tricks.<br /><em>Just pick, pin and pop.</em></h2></div>
      <div className="puffy-order-story-layout">
        <motion.figure initial={reduceMotion ? false : { opacity: 0, scale: .96 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true, amount: .25 }} transition={{ duration: .8, ease: premiumEase }}><img src="/api/media?slot=story-main" alt="An assorted Puffy Pops box" loading="lazy" /></motion.figure>
        <div className="puffy-order-steps">
          {[{ no: "01", title: "Choose the bites", copy: "Browse the right city menu, then pick a size and flavors." }, { no: "02", title: "Drop the pin", copy: "Put the pin at the delivery entrance so distance and fees stay accurate." }, { no: "03", title: "We route it", copy: "The order goes to the correct Puffy Pops branch with every choice attached." }].map((step, index) => <motion.article key={step.no} initial={reduceMotion ? false : { opacity: 0, x: 28 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: .65 }} transition={{ duration: .58, delay: index * .07, ease: premiumEase }}><span>{step.no}</span><div><h3>{step.title}</h3><p>{step.copy}</p></div><i>↗</i></motion.article>)}
        </div>
      </div>
    </section>

    <section className="cinema-highlights" aria-labelledby="highlight-title">
      <div className="cinema-section-heading">
        <div><p className="cinema-kicker">A few favorites</p><h2 id="highlight-title">Start with a classic.<br /><em>Then make it yours.</em></h2></div>
        <div className="cinema-rail-controls"><span aria-live="polite">0{activeHighlight + 1} / 0{highlights.length}</span><button type="button" onClick={() => moveRail(-1)} aria-label="Previous favorite">←</button><button type="button" onClick={() => moveRail(1)} aria-label="Next favorite">→</button></div>
      </div>
      <div className="cinema-highlight-rail" ref={railRef} onScroll={updateRailIndex} role="region" aria-roledescription="carousel" aria-label="Puffy Pops favorites">
        {highlights.map((item, index) => <motion.article className={`cinema-highlight-card ${item.tone}`} key={item.name} initial={reduceMotion ? false : { opacity: 0, scale: 0.94, clipPath: "inset(8% 8% 8% 8% round 42px)" }} whileInView={{ opacity: 1, scale: 1, clipPath: "inset(0% 0% 0% 0% round 42px)" }} viewport={{ once: true, amount: 0.25 }} transition={{ duration: 0.85, delay: index * 0.08, ease: premiumEase }}>
          <div className="cinema-highlight-image"><motion.img src={item.image} alt={`${item.name} Puffy Pops`} loading="lazy" whileHover={reduceMotion ? undefined : { scale: 1.055 }} transition={{ duration: 0.6, ease: premiumEase }} /></div>
          <div><span>{item.label}</span><h3>{item.name}</h3><a href="/menu">See it on the menu <i>↗</i></a></div>
        </motion.article>)}
      </div>
    </section>

    <section className="cinema-proof" aria-label="Puffy Pops across Egypt">
      <motion.div initial={reduceMotion ? false : { opacity: 0, y: 36 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration: 0.8, ease: premiumEase }}><strong>{branches.length}</strong><span>branches across Egypt</span></motion.div>
      <motion.div initial={reduceMotion ? false : { opacity: 0, y: 36 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration: 0.8, delay: 0.08, ease: premiumEase }}><strong>2</strong><span>city-specific menus</span></motion.div>
      <motion.div initial={reduceMotion ? false : { opacity: 0, y: 36 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.5 }} transition={{ duration: 0.8, delay: 0.16, ease: premiumEase }}><strong>1</strong><span>exact delivery pin</span></motion.div>
    </section>

    <section className="cinema-locations">
      <motion.div className="cinema-locations-copy" initial={reduceMotion ? false : { opacity: 0, x: -34 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: 0.35 }} transition={{ duration: 0.85, ease: premiumEase }}><p className="cinema-kicker">Alexandria to Cairo</p><h2>Local menu.<br /><em>Local team.</em></h2><p>Choose a branch yourself or let the website check which Puffy Pops location is nearest to you.</p><a href="/locations" className="cinema-button primary">Explore locations <span>↗</span></a></motion.div>
      <div className="cinema-branch-list">{branches.map((branch, index) => <motion.a href="/locations" key={branch.id} initial={reduceMotion ? false : { opacity: 0, x: 28 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, amount: 0.75 }} transition={{ duration: 0.6, delay: index * 0.055, ease: premiumEase }}><span>0{index + 1}</span><strong>{branch.name}</strong><small>{branch.city}</small><i>↗</i></motion.a>)}</div>
    </section>

    <section className="cinema-closing">
      <motion.div initial={reduceMotion ? false : { opacity: 0, scale: 0.94 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true, amount: 0.4 }} transition={{ duration: 0.9, ease: premiumEase }}><p className="cinema-kicker">Your next favorite</p><h2>Ready to make<br />the day <em>puffier?</em></h2><div className="cinema-actions"><a href="/menu" className="cinema-button light">Start an order <span>↗</span></a><a href="/track-order" className="cinema-button ghost">Track an order <span>→</span></a></div></motion.div>
    </section>

    <SiteFooter />
  </main>;
}
