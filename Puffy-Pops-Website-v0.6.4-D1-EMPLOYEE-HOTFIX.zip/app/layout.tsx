/* eslint-disable @next/next/no-css-tags -- Cloudflare needs this explicit static fallback. */
import type { Metadata } from "next";
import { Geist, DM_Serif_Display } from "next/font/google";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const display = DM_Serif_Display({
  variable: "--font-display",
  subsets: ["latin"],
  weight: "400",
});

export const metadata: Metadata = {
  title: "Puffy Pops Egypt | Spreading Joy",
  description:
    "Order Puffy Pops, cookies, brownies, coffee and more from your nearest Puffy Pops branch in Egypt.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/puffy-pops-logo.png",
    shortcut: "/puffy-pops-logo.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="stylesheet" href="/assets/storefront.css" />
      </head>
      <body
        className={`${geistSans.variable} ${display.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
