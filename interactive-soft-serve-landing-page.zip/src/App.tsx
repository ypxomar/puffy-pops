import { useEffect, useRef, useState } from 'react';
import type { CSSProperties } from 'react';
import { AnimatePresence, MotionConfig, motion, useReducedMotion, useScroll, useTransform } from 'motion/react';
import { ArrowDown, ArrowDownRight, ArrowLeft, ArrowRight, ArrowUp, ArrowUpRight, Menu, Minus, Plus, X } from 'lucide-react';
import { BRAND_SITE, branches, flavours, getMapUrl } from './data';
import type { City, Flavour } from './data';
import FlavourPicker from './components/FlavourPicker';
import { LocalProduct, preloadProducts, ProductDisplay } from './components/Product';
import OrderDialog from './components/OrderDialog';

function Instagram({ size = 16 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r=".8" fill="currentColor" stroke="none" /></svg>;
}

function Sparkle({ className = '' }: { className?: string }) {
  return <svg className={`sparkle ${className}`} viewBox="0 0 80 90" fill="none" aria-hidden="true"><path d="M42 6C39 31 32 39 7 45C34 46 40 53 42 83C47 56 52 47 74 43C50 39 45 30 42 6Z" stroke="currentColor" strokeWidth="2.6" strokeLinejoin="round" /></svg>;
}

function BrandLogo() {
  const [failed, setFailed] = useState(false);
  return <a className="brand-logo" href="#top" aria-label="Puffy Pops home">{failed ? <span>Puffy Pops</span> : <img src={`${BRAND_SITE}/api/media?slot=site-logo`} alt="Puffy Pops, spreading joy" onError={() => setFailed(true)} />}</a>;
}

function Header({ onOrder }: { onOrder: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    if (!menuOpen) return;
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') setMenuOpen(false); };
    document.addEventListener('keydown', closeOnEscape);
    return () => document.removeEventListener('keydown', closeOnEscape);
  }, [menuOpen]);
  const links = [
    { href: '#soft-serve', label: 'The soft serve' },
    { href: '#our-story', label: 'The Puffy feeling' },
    { href: '#find-us', label: 'Find your Puffy' },
  ];
  return (
    <header className="site-header">
      <div className="header-inner">
        <BrandLogo />
        <nav className="desktop-nav" aria-label="Main navigation">{links.map((link) => <a href={link.href} key={link.href}>{link.label}</a>)}</nav>
        <div className="header-actions">
          <button className="button button-primary header-cta" onClick={() => { setMenuOpen(false); onOrder(); }}>Get your swirl <ArrowUpRight size={17} /></button>
          <button type="button" className="mobile-menu-button icon-button" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} aria-controls="mobile-navigation" onClick={() => setMenuOpen((value) => !value)}>{menuOpen ? <X size={23} /> : <Menu size={23} />}</button>
        </div>
      </div>
      <AnimatePresence>{menuOpen && <motion.nav id="mobile-navigation" className="mobile-nav" aria-label="Mobile navigation" initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }}>{links.map((link) => <a href={link.href} key={link.href} onClick={() => setMenuOpen(false)}>{link.label}<ArrowUpRight size={20} /></a>)}<a href="#flavours" onClick={() => setMenuOpen(false)}>Pick your flavour<ArrowUpRight size={20} /></a></motion.nav>}</AnimatePresence>
    </header>
  );
}

function Hero({ flavour, onSelect }: { flavour: Flavour; onSelect: (id: string) => void }) {
  return (
    <section id="soft-serve" className="hero" aria-labelledby="hero-title">
      <svg className="hero-waves" viewBox="0 0 1440 900" fill="none" preserveAspectRatio="none" aria-hidden="true">
        <path d="M-100 807C173 615 327 859 675 756C992 662 1171 651 1550 760V1000H-100Z" fill="var(--tone)" fillOpacity=".23" />
        <path d="M-120 807C143 620 320 855 660 760C1009 662 1178 649 1570 769" /><path d="M-120 838C141 650 323 885 667 790C1016 692 1184 679 1570 799" /><path d="M-120 869C141 682 325 915 674 820C1023 722 1190 709 1570 829" />
      </svg>
      <motion.div className="hero-brand" initial={{ opacity: 0, y: 28 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.85, ease: [0.22, 1, 0.36, 1] }}><p className="eyebrow">INTRODUCING OUR ALL-NEW SOFT SERVE</p><h1 id="hero-title">Puffy Pops<span className="brand-registered">&reg;</span></h1></motion.div>
      <Sparkle className="hero-sparkle-left" /><Sparkle className="hero-sparkle-right" />
      <LocalProduct flavour={flavour} className="hero-local-product" />
      <motion.div className="hero-intro" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18, duration: 0.75 }}><h2>Your new<br className="desktop-break" /> soft spot.</h2><p>Meet our all-new soft serve.<br />A little swirl. A whole lot of joy.</p><a className="button button-primary" href="#flavours">Find your flavour <ArrowDownRight size={19} /></a></motion.div>
      <motion.div className="hero-flavours" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.75 }}><p className="eyebrow">WHAT'S YOUR SWIRL?</p><FlavourPicker selected={flavour.id} onSelect={onSelect} /></motion.div>
      <a href="#our-story" className="scroll-cue"><span className="scroll-cue-icon"><ArrowDown size={16} /></span><span>GOOD THINGS THIS WAY</span></a>
      <span className="hero-bottom-note">Made of happy.</span>
    </section>
  );
}

function Story({ flavour }: { flavour: Flavour }) {
  return (
    <section id="our-story" className="story-section" aria-labelledby="story-title">
      <div className="joy-ribbon" aria-hidden="true"><div className="ribbon-track">{[0, 1, 2, 3].map((item) => <span key={item}>SOFT SERVE. BIG FEELINGS.<Sparkle />THE SAME PUFFY JOY.<Sparkle /></span>)}</div></div>
      <svg className="story-orbit" viewBox="0 0 700 800" fill="none" aria-hidden="true"><ellipse cx="340" cy="390" rx="260" ry="337" transform="rotate(28 340 390)" /><ellipse cx="340" cy="390" rx="280" ry="361" transform="rotate(28 340 390)" /></svg>
      <LocalProduct flavour={flavour} className="story-local-product" />
      <motion.div className="story-copy" initial={{ opacity: 0, y: 25 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.75 }}><p className="eyebrow">SAME PUFFY. A SOFTER SIDE.</p><h2 id="story-title">A little joy.<br />With you.</h2><p className="story-description">For sunny strolls, long catch-ups, and just-because moments. Your favourite Puffy feeling, now in a ridiculously creamy swirl.</p><a className="text-link light-link" href={`${BRAND_SITE}/story`} target="_blank" rel="noopener noreferrer">A little more about us <ArrowUpRight size={19} /></a></motion.div>
      <Sparkle className="story-sparkle" /><span className="story-handwritten">Go on. Take the sweet way.</span>
    </section>
  );
}

function FlavourSection({ flavour, onSelect, onOrder }: { flavour: Flavour; onSelect: (id: string) => void; onOrder: () => void }) {
  const [detailsOpen, setDetailsOpen] = useState(false);
  const index = flavours.findIndex((option) => option.id === flavour.id);
  const changeFlavour = (direction: number) => onSelect(flavours[(index + direction + flavours.length) % flavours.length].id);
  return (
    <section id="flavours" className="flavours-section" aria-labelledby="flavour-title">
      <div className="flavour-section-heading"><p className="eyebrow">FOUR FLAVOURS. YOUR HAPPY PLACE.</p></div>
      <div className="flavour-content">
        <FlavourPicker selected={flavour.id} onSelect={onSelect} compact />
        <LocalProduct flavour={flavour} className="flavour-local-product" />
        <div className="flavour-description" aria-live="polite" aria-atomic="true"><h2 id="flavour-title" key={flavour.id}>{flavour.title[0]}<br /><span>{flavour.title[1]}</span></h2><p>{flavour.description}</p></div>
        <button className="details-toggle" aria-expanded={detailsOpen} aria-controls="flavour-details" onClick={() => setDetailsOpen((value) => !value)}>The sweet details {detailsOpen ? <Minus size={15} /> : <Plus size={15} />}</button>
        <AnimatePresence initial={false}>{detailsOpen && <motion.div id="flavour-details" className="flavour-details" initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }}><p>{flavour.details}</p><p>Please ask your branch for exact ingredients and allergen information before ordering.</p></motion.div>}</AnimatePresence>
        <button className="button button-primary flavour-order-button" onClick={onOrder}>This one's for me <ArrowUpRight size={19} /></button>
        <div className="flavour-pagination"><button className="icon-button" onClick={() => changeFlavour(-1)} aria-label="Previous flavour"><ArrowLeft size={19} /></button><span><strong>0{index + 1}</strong><span className="pagination-divider" />04</span><button className="icon-button" onClick={() => changeFlavour(1)} aria-label="Next flavour"><ArrowRight size={19} /></button></div>
      </div>
      <svg className="flavour-loop" viewBox="0 0 680 680" fill="none" aria-hidden="true"><path d="M344 42C650 14 705 480 442 588C179 695-25 503 94 248C153 122 386 102 468 258C550 414 371 570 227 450C133 371 195 227 306 258C434 294 365 415 286 360" /></svg>
    </section>
  );
}

function ProductJourney({ flavour, onSelect, onOrder }: { flavour: Flavour; onSelect: (id: string) => void; onOrder: () => void }) {
  const journeyRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: journeyRef, offset: ['start start', 'end end'] });
  const x = useTransform(scrollYProgress, [0, 0.07, 0.42, 0.55, 0.92, 1], ['0vw', '0vw', '-23vw', '-23vw', '22vw', '22vw']);
  const y = useTransform(scrollYProgress, [0, 0.1, 0.44, 0.6, 0.92, 1], ['0vh', '0vh', '-9vh', '-9vh', '-7vh', '-7vh']);
  const rotate = useTransform(scrollYProgress, [0, 0.12, 0.45, 0.6, 0.94, 1], [-9, -9, 9, 9, -8, -8]);
  const scale = useTransform(scrollYProgress, [0, 0.45, 0.6, 1], [1, 1.06, 1.06, 1.06]);
  return (
    <div ref={journeyRef} className="product-journey">
      <div className="product-stage" aria-hidden="true"><div className="product-stage-sticky"><div className="product-home"><motion.div className="travelling-product" style={{ x, y, rotate, scale }}><div className="floating-product"><ProductDisplay flavour={flavour} /></div></motion.div></div></div></div>
      <Hero flavour={flavour} onSelect={onSelect} /><Story flavour={flavour} /><FlavourSection flavour={flavour} onSelect={onSelect} onOrder={onOrder} />
    </div>
  );
}

function PuffyMoments() {
  const ref = useRef<HTMLElement>(null);
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], ['-5%', '5%']);
  return (
    <section ref={ref} className="moments-section" aria-labelledby="moments-title">
      <motion.img className="moments-image" src="/images/puffy-moments.jpg" alt="Two friends sharing strawberry Puffy Pops soft serve in the Mediterranean sunshine" loading="lazy" style={{ y: reduceMotion ? 0 : y }} /><div className="moments-shade" />
      <motion.div className="moments-copy" initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.4 }} transition={{ duration: 0.7 }}><p className="eyebrow">SWEET MOMENTS. EVEN SWEETER COMPANY.</p><h2 id="moments-title">Meet me<br />at Puffy.</h2><p>Bring your people. We'll bring the swirls.</p><a className="button button-light" href="#find-us">Let's make a date <ArrowUpRight size={19} /></a></motion.div>
    </section>
  );
}

function Locations() {
  const [city, setCity] = useState<City>('Alexandria');
  return (
    <section className="locations-section" id="find-us" aria-labelledby="locations-title">
      <div className="locations-copy"><p className="eyebrow">ALEXANDRIA ROOTS. CAIRO ENERGY.</p><h2 id="locations-title">Find your<br />Puffy place.</h2><p>Your next happy little moment is closer than you think.</p><svg className="location-doodle" viewBox="0 0 175 75" fill="none" aria-hidden="true"><path d="M5 29C45-8 91 12 91 37C91 74 40 76 55 37C71-1 124 21 162 38M150 20L167 41L139 47" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg></div>
      <div className="location-finder">
        <div className="city-tabs" role="group" aria-label="Filter branches by city">{(['Alexandria', 'Cairo'] as City[]).map((option) => <button key={option} className={city === option ? 'is-active' : ''} aria-pressed={city === option} onClick={() => setCity(option)}>{option}<span>0{branches.filter((branch) => branch.city === option).length}</span></button>)}</div>
        <div className="location-list" aria-live="polite">{branches.filter((branch) => branch.city === city).map((branch) => <a className="location-row" key={branch.id} href={getMapUrl(branch)} target="_blank" rel="noopener noreferrer" aria-label={`Get directions to Puffy Pops ${branch.name}`}><div><h3>{branch.name}</h3><p>{branch.address}</p></div><span className="location-arrow"><ArrowUpRight size={21} /></span></a>)}</div>
        <p className="location-help">Not sure which way? <a href="tel:+201002018510">Give us a ring <ArrowUpRight size={13} /></a></p>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-top"><p>Spreading joy. One swirl at a time.</p><nav aria-label="Footer navigation"><a href={`${BRAND_SITE}/menu`} target="_blank" rel="noopener noreferrer">The full menu <ArrowUpRight size={14} /></a><a href={`${BRAND_SITE}/story`} target="_blank" rel="noopener noreferrer">Our story <ArrowUpRight size={14} /></a><a href="https://www.instagram.com/puffypopseg/" target="_blank" rel="noopener noreferrer"><Instagram size={16} /> Follow the joy</a></nav></div>
      <div className="footer-wordmark" aria-label="Puffy Pops">Puffy Pops<span>&reg;</span></div>
      <div className="footer-bottom"><p>&copy; {new Date().getFullYear()} Puffy Pops Egypt. Made of happy.</p><a href="#top">Back to the sweet top <ArrowUp size={15} /></a></div>
    </footer>
  );
}

function getInitialFlavour() {
  try {
    const stored = localStorage.getItem('puffy-soft-serve-flavour');
    return flavours.some((flavour) => flavour.id === stored) ? stored! : flavours[0].id;
  } catch { return flavours[0].id; }
}

export default function App() {
  const [selected, setSelected] = useState(getInitialFlavour);
  const [orderOpen, setOrderOpen] = useState(false);
  const reduceMotion = useReducedMotion();
  const flavour = flavours.find((option) => option.id === selected) || flavours[0];
  useEffect(() => { preloadProducts(flavours); }, []);
  useEffect(() => { try { localStorage.setItem('puffy-soft-serve-flavour', selected); } catch { /* Selection also works without browser storage. */ } }, [selected]);
  const theme = { '--accent': flavour.accent, '--page-bg': flavour.background, '--tone': flavour.tone } as CSSProperties;
  return (
    <MotionConfig reducedMotion="user">
      <div id="top" className={`site-shell ${reduceMotion ? 'reduced-motion' : ''}`} style={theme}>
        <a href="#main-content" className="skip-link">Skip to the good stuff</a><Header onOrder={() => setOrderOpen(true)} />
        <main id="main-content" tabIndex={-1}><ProductJourney flavour={flavour} onSelect={setSelected} onOrder={() => setOrderOpen(true)} /><PuffyMoments /><Locations /></main>
        <Footer /><OrderDialog open={orderOpen} onClose={() => setOrderOpen(false)} flavour={flavour} onFlavourChange={setSelected} />
      </div>
    </MotionConfig>
  );
}
